package com.company.customerdataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
